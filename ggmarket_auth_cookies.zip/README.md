# ggmarket auth cookies

Firefox and Chrome add-on which copies necessary cookies to help register new product on https://ggmarket.gg.

## Instructions
This addon adds an icon to the toolbar, which triggers a popup window, where user must give her/his permission to copy cookies:

![Screenshot](./doc/screenshot-01.png?raw=true)

## Licence

[GPLv3](https://github.com/hrdl-github/cookies-txt/blob/master/LICENCE)
