var browser = browser || chrome;

alert(browser.i18n.getMessage('noauth'));